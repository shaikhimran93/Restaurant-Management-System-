@echo off
rem Double-click this file to compile and start the Restaurant Manager.
cd /d "%~dp0"

where javac >nul 2>nul
if errorlevel 1 (
  echo.
  echo  Java JDK nahi mila.  Pehle JDK install karo:  https://adoptium.net
  echo  Install karte waqt "Add to PATH" wale option ko ON rakhna.
  echo  Phir naya window kholke run.bat dobara chalao.
  echo.
  pause
  exit /b 1
)

if not exist out mkdir out
javac -encoding UTF-8 -d out src\rms\*.java
if errorlevel 1 (
  echo.
  echo  Compile error aaya. Upar ka message screenshot karke bhej do.
  pause
  exit /b 1
)

echo Starting Restaurant Manager...
java -cp out rms.Main
