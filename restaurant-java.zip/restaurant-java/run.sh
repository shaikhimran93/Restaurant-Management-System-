#!/bin/sh
# Mac / Linux:  sh run.sh        (add "test" to run the self-checks instead)
cd "$(dirname "$0")" || exit 1
mkdir -p out
if [ "$1" = "test" ]; then
  javac -encoding UTF-8 -d out src/rms/*.java test/rms/*.java || exit 1
  java -Djava.awt.headless=true -cp out rms.StoreTest
  java -Djava.awt.headless=true -cp out rms.GuiSmokeTest
else
  javac -encoding UTF-8 -d out src/rms/*.java || exit 1
  java -cp out rms.Main
fi
