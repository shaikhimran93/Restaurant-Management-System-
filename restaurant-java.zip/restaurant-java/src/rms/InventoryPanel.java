package rms;

import rms.Model.Ingredient;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Ingredient stock: low-stock flags, restocking, new ingredients. */
final class InventoryPanel extends JPanel implements Refreshable {
    private final Store store;
    private final DefaultTableModel model = Ui.model("Ingredient", "In stock", "Reorder at", "Status");
    private final JTable table = new JTable(model);
    private final List<Ingredient> shown = new ArrayList<>();

    private final JTextField name = new JTextField(12);
    private final JTextField unit = new JTextField(5);
    private final JTextField stock = new JTextField(6);
    private final JTextField reorder = new JTextField(6);

    InventoryPanel(Store store) {
        super(new BorderLayout(0, 10));
        this.store = store;
        setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        JPanel form = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        form.setBorder(BorderFactory.createTitledBorder("Add an ingredient"));
        form.add(new JLabel("Name"));
        form.add(name);
        form.add(new JLabel("Unit (kg, l, pcs)"));
        form.add(unit);
        form.add(new JLabel("Opening stock"));
        form.add(stock);
        form.add(new JLabel("Reorder at"));
        form.add(reorder);
        form.add(Ui.button("Add", this::addIngredient));
        add(form, BorderLayout.NORTH);

        table.setRowHeight(26);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getColumnModel().getColumn(3).setCellRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foc, int r, int c) {
                Component comp = super.getTableCellRendererComponent(t, v, sel, foc, r, c);
                if (!sel) comp.setForeground(r < shown.size() && shown.get(r).low() ? Ui.BAD : Ui.OK);
                return comp;
            }
        });
        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        actions.add(Ui.button("Restock selected", this::restock));
        JLabel hint = new JLabel("Stock goes down automatically when a bill is paid (using each dish's recipe).");
        hint.setForeground(Ui.MUTED);
        actions.add(hint);
        add(actions, BorderLayout.SOUTH);
        refresh();
    }

    private void addIngredient() {
        try {
            store.addIngredient(name.getText(), unit.getText(), Ui.numberOrZero(stock.getText()), Ui.numberOrZero(reorder.getText()));
            name.setText("");
            unit.setText("");
            stock.setText("");
            reorder.setText("");
            refresh();
        } catch (RuntimeException e) {
            Ui.error(this, e);
        }
    }

    private void restock() {
        int row = table.getSelectedRow();
        if (row < 0 || row >= shown.size()) {
            Ui.info(this, "Select an ingredient in the table first.");
            return;
        }
        Ingredient i = shown.get(row);
        String in = JOptionPane.showInputDialog(this, "How much " + i.unit + " of " + i.name + " did you add?");
        if (in == null) return;
        try {
            store.restock(i.name, Ui.number(in));
            refresh();
            table.setRowSelectionInterval(row, row);
        } catch (RuntimeException e) {
            Ui.error(this, e);
        }
    }

    @Override public void refresh() {
        model.setRowCount(0);
        shown.clear();
        for (Ingredient i : store.ingredients) {
            shown.add(i);
            model.addRow(new Object[] {
                    i.name,
                    String.format(Locale.ENGLISH, "%.2f %s", i.stock, i.unit),
                    i.reorderLevel + " " + i.unit,
                    i.low() ? "LOW - reorder" : "OK"});
        }
    }
}
