package rms;

import rms.Model.DiningTable;

import javax.swing.*;
import java.awt.*;

/** Home screen: today's numbers and the table map. Click a table to take or review its order. */
final class FloorPanel extends JPanel implements Refreshable {
    private final Store store;
    private final JLabel sales = value();
    private final JLabel bills = value();
    private final JLabel open = value();
    private final JLabel low = value();
    private final JPanel grid = new JPanel(new GridLayout(0, 4, 12, 12));

    FloorPanel(Store store) {
        super(new BorderLayout(0, 16));
        this.store = store;
        setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        JPanel stats = new JPanel(new GridLayout(1, 4, 12, 0));
        stats.add(card("TODAY'S SALES", sales));
        stats.add(card("BILLS TODAY", bills));
        stats.add(card("OPEN ORDERS", open));
        stats.add(card("LOW-STOCK ITEMS", low));
        add(stats, BorderLayout.NORTH);

        JPanel holder = new JPanel(new BorderLayout());
        holder.add(grid, BorderLayout.NORTH);
        JScrollPane sp = new JScrollPane(holder);
        sp.setBorder(BorderFactory.createTitledBorder("Tables - click one to take or review its order"));
        add(sp, BorderLayout.CENTER);
        refresh();
    }

    private static JLabel value() {
        JLabel l = new JLabel("0", SwingConstants.CENTER);
        l.setFont(l.getFont().deriveFont(Font.BOLD, 26f));
        return l;
    }

    private static JPanel card(String caption, JLabel v) {
        JPanel p = new JPanel(new BorderLayout(0, 4));
        p.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0xE0D6C8)),
                BorderFactory.createEmptyBorder(12, 12, 12, 12)));
        JLabel c = new JLabel(caption, SwingConstants.CENTER);
        c.setForeground(Ui.MUTED);
        c.setFont(c.getFont().deriveFont(11f));
        p.add(v, BorderLayout.CENTER);
        p.add(c, BorderLayout.SOUTH);
        return p;
    }

    @Override public void refresh() {
        sales.setText(Ui.money(store.todaySales()));
        bills.setText(String.valueOf(store.todayBills()));
        open.setText(String.valueOf(store.openOrderCount()));
        int lowCount = store.lowStockCount();
        low.setText(String.valueOf(lowCount));
        low.setForeground(lowCount > 0 ? Ui.BAD : Color.BLACK);

        grid.removeAll();
        for (DiningTable t : store.tables) {
            boolean busy = store.openOrder(t.id) != null;
            JButton b = new JButton("<html><center><b style='font-size:14px'>" + Ui.html(t.label) + "</b><br>"
                    + t.seats + " seats &middot; " + (busy ? "Occupied" : "Free") + "</center></html>");
            b.setPreferredSize(new Dimension(150, 84));
            b.setContentAreaFilled(false);
            b.setOpaque(true);
            b.setBackground(busy ? Ui.BUSY : Color.WHITE);
            b.setBorder(BorderFactory.createLineBorder(busy ? Ui.BRAND : new Color(0xD8CDBD), busy ? 2 : 1));
            b.setFocusPainted(false);
            b.addActionListener(e -> {
                Window w = SwingUtilities.getWindowAncestor(this);
                new OrderDialog(w, store, t, this::refresh).setVisible(true);
            });
            grid.add(b);
        }
        grid.revalidate();
        grid.repaint();
    }
}
