package rms;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

/** Sales reports: daily revenue, best sellers, payment methods. */
final class ReportsPanel extends JPanel implements Refreshable {
    private final Store store;
    private final JLabel summary = Ui.heading(" ");
    private final DefaultTableModel daily = Ui.model("Date", "Bills", "Revenue");
    private final DefaultTableModel sellers = Ui.model("Dish", "Sold", "Revenue");
    private final DefaultTableModel methods = Ui.model("Payment method", "Bills", "Amount");

    ReportsPanel(Store store) {
        super(new BorderLayout(0, 10));
        this.store = store;
        setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));
        add(summary, BorderLayout.NORTH);

        JPanel bottom = new JPanel(new GridLayout(1, 2, 12, 0));
        bottom.add(titled("Best sellers", sellers));
        bottom.add(titled("Payment methods", methods));

        JPanel body = new JPanel(new GridLayout(2, 1, 0, 12));
        body.add(titled("Last 14 days", daily));
        body.add(bottom);
        add(body, BorderLayout.CENTER);
        refresh();
    }

    private static JScrollPane titled(String title, DefaultTableModel m) {
        JTable t = new JTable(m);
        t.setRowHeight(24);
        JScrollPane sp = new JScrollPane(t);
        sp.setBorder(BorderFactory.createTitledBorder(title));
        return sp;
    }

    @Override public void refresh() {
        double total = 0;
        for (Model.Bill b : store.bills) total += b.total;
        summary.setText("All time: " + store.bills.size() + " bills, " + Ui.money(Store.round2(total)) + " revenue");

        daily.setRowCount(0);
        for (Store.DayRow r : store.dailyRevenue(14)) daily.addRow(new Object[] {r.day(), r.bills(), Ui.money(r.revenue())});
        sellers.setRowCount(0);
        for (Store.SellerRow r : store.topSellers(10)) sellers.addRow(new Object[] {r.name(), r.sold(), Ui.money(r.revenue())});
        methods.setRowCount(0);
        for (Store.MethodRow r : store.byMethod()) methods.addRow(new Object[] {r.method(), r.bills(), Ui.money(r.amount())});
    }
}
