package rms;

import rms.Model.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/** Waiter screen for one table: add dishes, remove, serve, and go to the bill. */
final class OrderDialog extends JDialog {
    private final Store store;
    private final DiningTable table;
    private final Runnable onChange;

    private final JComboBox<Dish> dishes = new JComboBox<>();
    private final JSpinner qty = new JSpinner(new SpinnerNumberModel(1, 1, 20, 1));
    private final JTextField note = new JTextField(14);
    private final DefaultTableModel model = Ui.model("Item", "Qty", "Amount", "Status");
    private final JTable grid = new JTable(model);
    private final JLabel subtotal = new JLabel();
    private final List<Line> shown = new ArrayList<>();

    OrderDialog(Window owner, Store store, DiningTable table, Runnable onChange) {
        super(owner, "Table " + table.label + " (" + table.seats + " seats)", ModalityType.APPLICATION_MODAL);
        this.store = store;
        this.table = table;
        this.onChange = onChange;

        for (Dish d : store.menu) if (d.available) dishes.addItem(d);
        dishes.setRenderer(new DefaultListCellRenderer() {
            @Override public Component getListCellRendererComponent(JList<?> list, Object v, int i, boolean sel, boolean foc) {
                super.getListCellRendererComponent(list, v, i, sel, foc);
                if (v instanceof Dish d) setText(d.name + "  -  " + Ui.money(d.price) + (d.veg ? "  (veg)" : "  (non-veg)"));
                return this;
            }
        });

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        top.setBorder(BorderFactory.createTitledBorder("Add to order"));
        top.add(dishes);
        top.add(new JLabel("Qty"));
        top.add(qty);
        top.add(new JLabel("Note"));
        top.add(note);
        top.add(Ui.button("Add", this::addSelected));

        grid.setRowHeight(26);
        grid.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JPanel btns = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 8));
        btns.add(Ui.button("Remove selected", this::removeSelected));
        btns.add(Ui.button("Mark selected served", this::serveSelected));
        btns.add(Ui.button("Generate bill", this::generateBill));
        btns.add(Ui.button("Close", this::dispose));
        subtotal.setFont(subtotal.getFont().deriveFont(Font.BOLD, 14f));
        JPanel bottom = new JPanel(new BorderLayout());
        bottom.setBorder(BorderFactory.createEmptyBorder(0, 12, 0, 0));
        bottom.add(subtotal, BorderLayout.WEST);
        bottom.add(btns, BorderLayout.EAST);

        setLayout(new BorderLayout(0, 6));
        add(top, BorderLayout.NORTH);
        add(new JScrollPane(grid), BorderLayout.CENTER);
        add(bottom, BorderLayout.SOUTH);
        setSize(820, 470);
        setLocationRelativeTo(owner);
        reload();
    }

    private void reload() {
        model.setRowCount(0);
        shown.clear();
        Order o = store.openOrder(table.id);
        double sub = 0;
        if (o != null) {
            for (Line l : o.lines) {
                shown.add(l);
                String name = l.name + (l.note.isEmpty() ? "" : "   (" + l.note + ")");
                model.addRow(new Object[] {name, l.qty, Ui.money(l.amount()), l.status});
                sub += l.amount();
            }
        }
        subtotal.setText("Subtotal: " + Ui.money(sub));
        onChange.run();
    }

    private Line selectedLine() {
        int r = grid.getSelectedRow();
        if (r < 0 || r >= shown.size()) {
            Ui.info(this, "Select an item in the list first.");
            return null;
        }
        return shown.get(r);
    }

    private void addSelected() {
        Dish d = (Dish) dishes.getSelectedItem();
        if (d == null) return;
        try {
            store.addItem(table.id, d.id, (Integer) qty.getValue(), note.getText());
            note.setText("");
            qty.setValue(1);
            reload();
        } catch (RuntimeException e) {
            Ui.error(this, e);
        }
    }

    private void removeSelected() {
        Line l = selectedLine();
        if (l == null) return;
        try {
            store.removeLine(l.id);
            reload();
        } catch (RuntimeException e) {
            Ui.error(this, e);
        }
    }

    private void serveSelected() {
        Line l = selectedLine();
        if (l == null) return;
        try {
            store.serve(l.id);
            reload();
        } catch (RuntimeException e) {
            Ui.error(this, e);
        }
    }

    private void generateBill() {
        Order o = store.openOrder(table.id);
        if (o == null || o.lines.isEmpty()) {
            Ui.info(this, "This table has no items yet.");
            return;
        }
        BillDialog d = new BillDialog(this, store, o);
        d.setVisible(true);
        reload();
        if (d.paid()) dispose();
    }
}
