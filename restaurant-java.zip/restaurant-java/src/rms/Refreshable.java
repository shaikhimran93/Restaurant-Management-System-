package rms;

/** A screen that can redraw itself from the Store. */
interface Refreshable {
    void refresh();
}
