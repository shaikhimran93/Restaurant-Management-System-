package rms;

import rms.Model.Line;
import rms.Model.Status;

import javax.swing.*;
import java.awt.*;
import java.time.format.DateTimeFormatter;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/** Kitchen board: three columns (New / Preparing / Ready). Select a ticket and press the button below it. */
final class KitchenPanel extends JPanel implements Refreshable {
    private static final DateTimeFormatter HM = DateTimeFormatter.ofPattern("HH:mm");

    private final Store store;
    private final Map<Status, JList<Store.Ticket>> lists = new EnumMap<>(Status.class);
    private final Map<Status, JLabel> titles = new EnumMap<>(Status.class);
    private final Map<Status, String> names = new EnumMap<>(Status.class);

    KitchenPanel(Store store) {
        super(new GridLayout(1, 3, 12, 0));
        this.store = store;
        setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));
        add(column(Status.NEW, "New orders", "Start cooking"));
        add(column(Status.PREPARING, "Preparing", "Mark ready"));
        add(column(Status.READY, "Ready to serve", null));
        refresh();
    }

    private JPanel column(Status s, String name, String buttonText) {
        names.put(s, name);
        JLabel title = Ui.heading(name);
        titles.put(s, title);

        JList<Store.Ticket> list = new JList<>();
        list.setCellRenderer(new TicketRenderer());
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        lists.put(s, list);

        JPanel p = new JPanel(new BorderLayout(0, 8));
        p.add(title, BorderLayout.NORTH);
        p.add(new JScrollPane(list), BorderLayout.CENTER);
        if (buttonText != null) {
            p.add(Ui.button(buttonText, () -> advanceSelected(s)), BorderLayout.SOUTH);
        } else {
            JLabel hint = new JLabel("Waiter serves these from the table screen.", SwingConstants.CENTER);
            hint.setForeground(Ui.MUTED);
            p.add(hint, BorderLayout.SOUTH);
        }
        return p;
    }

    private void advanceSelected(Status s) {
        Store.Ticket t = lists.get(s).getSelectedValue();
        if (t == null) {
            Ui.info(this, "Click a ticket first.");
            return;
        }
        try {
            store.advance(t.line().id);
        } catch (RuntimeException e) {
            Ui.error(this, e);
        }
        refresh();
    }

    @Override public void refresh() {
        for (Status s : lists.keySet()) {
            JList<Store.Ticket> list = lists.get(s);
            Store.Ticket sel = list.getSelectedValue();
            int selId = sel == null ? -1 : sel.line().id;

            List<Store.Ticket> tickets = store.kitchenTickets(s);
            list.setListData(tickets.toArray(new Store.Ticket[0]));
            for (int i = 0; i < tickets.size(); i++) {
                if (tickets.get(i).line().id == selId) list.setSelectedIndex(i);
            }
            titles.get(s).setText(names.get(s) + " (" + tickets.size() + ")");
        }
    }

    private static final class TicketRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object v, int i, boolean sel, boolean foc) {
            super.getListCellRendererComponent(list, v, i, sel, foc);
            if (v instanceof Store.Ticket t) {
                Line l = t.line();
                String note = l.note.isEmpty() ? "" : "<br><font color='#B26A00'>Note: " + Ui.html(l.note) + "</font>";
                setText("<html><b>" + l.qty + " x " + Ui.html(l.name) + "</b><br>Table "
                        + Ui.html(t.tableLabel()) + " &middot; " + l.created.format(HM) + note + "</html>");
                setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(0xE0D6C8)),
                        BorderFactory.createEmptyBorder(6, 6, 6, 6)));
            }
            return this;
        }
    }
}
