package rms;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Plain data classes. Everything is Serializable so the Store can save it all to one file. */
public final class Model {
    private Model() {}

    /** Kitchen status of one order line: NEW -> PREPARING -> READY -> SERVED. */
    public enum Status { NEW, PREPARING, READY, SERVED }

    /** A dish on the menu. */
    public static class Dish implements Serializable {
        private static final long serialVersionUID = 1L;
        public int id;
        public String category;
        public String name;
        public double price;
        public boolean veg;
        public boolean available = true;
        /** ingredient name -> quantity used per portion (used to cut stock when billed) */
        public Map<String, Double> recipe = new LinkedHashMap<>();

        @Override public String toString() { return name; }
    }

    public static class Ingredient implements Serializable {
        private static final long serialVersionUID = 1L;
        public String name;
        public String unit;
        public double stock;
        public double reorderLevel;

        public boolean low() { return stock <= reorderLevel; }
    }

    public static class DiningTable implements Serializable {
        private static final long serialVersionUID = 1L;
        public int id;
        public String label;
        public int seats;
    }

    /** One dish ordered at a table (with quantity). */
    public static class Line implements Serializable {
        private static final long serialVersionUID = 1L;
        public int id;
        public int dishId;
        public String name;
        public int qty;
        public double unitPrice;
        public String note = "";
        public Status status = Status.NEW;
        public LocalDateTime created;

        public double amount() { return qty * unitPrice; }
    }

    public static class Order implements Serializable {
        private static final long serialVersionUID = 1L;
        public int id;
        public int tableId;
        public boolean open = true;
        public LocalDateTime created;
        public LocalDateTime closed;
        public List<Line> lines = new ArrayList<>();

        public double subtotal() {
            double s = 0;
            for (Line l : lines) s += l.amount();
            return s;
        }
    }

    public static class Bill implements Serializable {
        private static final long serialVersionUID = 1L;
        public int orderId;
        public int tableId;
        public String tableLabel;
        public Order order;
        public double subtotal;
        public double discount;
        public double tax;
        public double total;
        public String method;
        public LocalDateTime paidAt;
    }
}
