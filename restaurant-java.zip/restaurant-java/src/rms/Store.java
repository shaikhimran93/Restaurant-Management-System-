package rms;

import rms.Model.*;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * All restaurant data + business rules (no screens in here, so it can be tested on its own).
 * Every change is saved to a single file straight away.
 */
public class Store implements Serializable {
    private static final long serialVersionUID = 1L;
    public static final double GST_RATE = 0.05; // 5% GST - change here

    public final List<String> categories = new ArrayList<>();
    public final List<Dish> menu = new ArrayList<>();
    public final List<Ingredient> ingredients = new ArrayList<>();
    public final List<DiningTable> tables = new ArrayList<>();
    public final List<Order> orders = new ArrayList<>();
    public final List<Bill> bills = new ArrayList<>();
    private int nextDishId = 1;
    private int nextOrderId = 1;
    private int nextLineId = 1;
    private transient Path file;

    /** A line waiting in the kitchen, together with where it belongs. */
    public record Ticket(Order order, Line line, String tableLabel) {}
    public record DayRow(LocalDate day, int bills, double revenue) {}
    public record SellerRow(String name, int sold, double revenue) {}
    public record MethodRow(String method, int bills, double amount) {}

    // ------------------------------------------------------------------ load / save

    /** Loads the data file, or creates it with sample data the first time. */
    public static Store load(Path file) {
        if (Files.exists(file)) {
            try (ObjectInputStream in = new ObjectInputStream(Files.newInputStream(file))) {
                Store s = (Store) in.readObject();
                s.file = file;
                return s;
            } catch (Exception e) {
                System.err.println("Could not read " + file + " (" + e + "). Starting with fresh data.");
            }
        }
        Store s = new Store();
        Seed.fill(s);
        s.file = file;
        s.save();
        return s;
    }

    /** A store that is never written to disk (used by tests). */
    public static Store inMemory() {
        Store s = new Store();
        Seed.fill(s);
        return s;
    }

    private void save() {
        if (file == null) return;
        try (ObjectOutputStream out = new ObjectOutputStream(Files.newOutputStream(file))) {
            out.writeObject(this);
        } catch (IOException e) {
            System.err.println("Could not save data: " + e);
        }
    }

    // ------------------------------------------------------------------ lookups

    public Dish findDish(int id) {
        for (Dish d : menu) if (d.id == id) return d;
        return null;
    }

    public DiningTable findTable(int id) {
        for (DiningTable t : tables) if (t.id == id) return t;
        return null;
    }

    public String tableLabel(int tableId) {
        DiningTable t = findTable(tableId);
        return t == null ? "?" : t.label;
    }

    public Ingredient findIngredient(String name) {
        for (Ingredient i : ingredients) if (i.name.equalsIgnoreCase(name)) return i;
        return null;
    }

    public Order findOrder(int id) {
        for (Order o : orders) if (o.id == id) return o;
        return null;
    }

    /** The running (unpaid) order of a table, or null if the table is free. */
    public Order openOrder(int tableId) {
        for (Order o : orders) if (o.open && o.tableId == tableId) return o;
        return null;
    }

    private Order orderOfLine(int lineId) {
        for (Order o : orders)
            for (Line l : o.lines) if (l.id == lineId) return o;
        return null;
    }

    private Line findLine(int lineId) {
        Order o = orderOfLine(lineId);
        if (o == null) return null;
        for (Line l : o.lines) if (l.id == lineId) return l;
        return null;
    }

    // ------------------------------------------------------------------ ordering

    public Line addItem(int tableId, int dishId, int qty, String note) {
        Dish d = findDish(dishId);
        if (d == null || !d.available) throw new IllegalArgumentException("This item is not available.");
        if (qty < 1) throw new IllegalArgumentException("Quantity must be at least 1.");
        if (findTable(tableId) == null) throw new IllegalArgumentException("Unknown table.");

        Order o = openOrder(tableId);
        if (o == null) {
            o = new Order();
            o.id = nextOrderId++;
            o.tableId = tableId;
            o.created = LocalDateTime.now();
            orders.add(o);
        }
        Line l = new Line();
        l.id = nextLineId++;
        l.dishId = d.id;
        l.name = d.name;
        l.qty = qty;
        l.unitPrice = d.price;
        l.note = note == null ? "" : note.trim();
        l.created = LocalDateTime.now();
        o.lines.add(l);
        save();
        return l;
    }

    /** Waiter can only remove an item the kitchen has not started yet. */
    public void removeLine(int lineId) {
        Order o = orderOfLine(lineId);
        Line l = findLine(lineId);
        if (o == null || l == null) throw new IllegalArgumentException("Item not found.");
        if (l.status != Status.NEW) throw new IllegalStateException("The kitchen has already started this item.");
        o.lines.remove(l);
        if (o.lines.isEmpty()) orders.remove(o); // nothing left -> table becomes free
        save();
    }

    /** Kitchen moves a line NEW -> PREPARING -> READY. */
    public void advance(int lineId) {
        Line l = findLine(lineId);
        if (l == null) throw new IllegalArgumentException("Item not found.");
        if (l.status == Status.NEW) l.status = Status.PREPARING;
        else if (l.status == Status.PREPARING) l.status = Status.READY;
        save();
    }

    public void serve(int lineId) {
        Line l = findLine(lineId);
        if (l == null) throw new IllegalArgumentException("Item not found.");
        if (l.status != Status.READY) throw new IllegalStateException("Only items marked READY by the kitchen can be served.");
        l.status = Status.SERVED;
        save();
    }

    public List<Ticket> kitchenTickets(Status status) {
        List<Ticket> out = new ArrayList<>();
        for (Order o : orders) {
            if (!o.open) continue;
            for (Line l : o.lines) if (l.status == status) out.add(new Ticket(o, l, tableLabel(o.tableId)));
        }
        out.sort(Comparator.comparing((Ticket t) -> t.line().created).thenComparingInt(t -> t.line().id));
        return out;
    }

    // ------------------------------------------------------------------ billing

    public static double round2(double v) { return Math.round(v * 100.0) / 100.0; }

    /** Returns {discount, tax, total} for a subtotal and a discount percentage. */
    public static double[] calc(double subtotal, double discountPct) {
        double pct = Math.min(100, Math.max(0, discountPct));
        double discount = round2(subtotal * pct / 100);
        double tax = round2((subtotal - discount) * GST_RATE);
        double total = round2(subtotal - discount + tax);
        return new double[] {discount, tax, total};
    }

    public Bill bill(int orderId, double discountPct, String method) {
        Order o = findOrder(orderId);
        if (o == null || !o.open) throw new IllegalStateException("This order is already billed or does not exist.");
        if (o.lines.isEmpty()) throw new IllegalStateException("Cannot bill an empty order.");

        double subtotal = round2(o.subtotal());
        double[] c = calc(subtotal, discountPct);

        // cut ingredient stock using each dish's recipe
        for (Line l : o.lines) {
            Dish d = findDish(l.dishId);
            if (d == null) continue;
            for (Map.Entry<String, Double> r : d.recipe.entrySet()) {
                Ingredient ing = findIngredient(r.getKey());
                if (ing != null) ing.stock = Math.max(0, ing.stock - r.getValue() * l.qty);
            }
        }

        o.open = false;
        o.closed = LocalDateTime.now();

        Bill b = new Bill();
        b.orderId = o.id;
        b.tableId = o.tableId;
        b.tableLabel = tableLabel(o.tableId);
        b.order = o;
        b.subtotal = subtotal;
        b.discount = c[0];
        b.tax = c[1];
        b.total = c[2];
        b.method = method == null ? "Cash" : method;
        b.paidAt = LocalDateTime.now();
        bills.add(b);
        save();
        return b;
    }

    // ------------------------------------------------------------------ menu admin

    public Dish addDish(String category, String name, double price, boolean veg) {
        if (name == null || name.isBlank()) throw new IllegalArgumentException("Enter a name.");
        if (price < 0) throw new IllegalArgumentException("Price cannot be negative.");
        Dish d = new Dish();
        d.id = nextDishId++;
        d.category = category;
        d.name = name.trim();
        d.price = price;
        d.veg = veg;
        menu.add(d);
        if (!categories.contains(category)) categories.add(category);
        save();
        return d;
    }

    public void setPrice(int dishId, double price) {
        Dish d = findDish(dishId);
        if (d == null) throw new IllegalArgumentException("Item not found.");
        if (price < 0) throw new IllegalArgumentException("Price cannot be negative.");
        d.price = price;
        save();
    }

    public void toggleAvailable(int dishId) {
        Dish d = findDish(dishId);
        if (d == null) throw new IllegalArgumentException("Item not found.");
        d.available = !d.available;
        save();
    }

    // ------------------------------------------------------------------ inventory

    public Ingredient addIngredient(String name, String unit, double stock, double reorderLevel) {
        if (name == null || name.isBlank()) throw new IllegalArgumentException("Enter an ingredient name.");
        if (findIngredient(name.trim()) != null) throw new IllegalArgumentException("That ingredient already exists.");
        Ingredient i = new Ingredient();
        i.name = name.trim();
        i.unit = (unit == null || unit.isBlank()) ? "pcs" : unit.trim();
        i.stock = Math.max(0, stock);
        i.reorderLevel = Math.max(0, reorderLevel);
        ingredients.add(i);
        save();
        return i;
    }

    public void restock(String name, double qty) {
        Ingredient i = findIngredient(name);
        if (i == null) throw new IllegalArgumentException("Ingredient not found.");
        if (qty <= 0) throw new IllegalArgumentException("Enter a quantity greater than 0.");
        i.stock += qty;
        save();
    }

    public int lowStockCount() {
        int n = 0;
        for (Ingredient i : ingredients) if (i.low()) n++;
        return n;
    }

    // ------------------------------------------------------------------ reports

    public double todaySales() {
        LocalDate today = LocalDate.now();
        double s = 0;
        for (Bill b : bills) if (b.paidAt.toLocalDate().equals(today)) s += b.total;
        return round2(s);
    }

    public int todayBills() {
        LocalDate today = LocalDate.now();
        int n = 0;
        for (Bill b : bills) if (b.paidAt.toLocalDate().equals(today)) n++;
        return n;
    }

    public int openOrderCount() {
        int n = 0;
        for (Order o : orders) if (o.open) n++;
        return n;
    }

    public List<DayRow> dailyRevenue(int maxDays) {
        Map<LocalDate, double[]> m = new TreeMap<>(Comparator.reverseOrder());
        for (Bill b : bills) {
            double[] a = m.computeIfAbsent(b.paidAt.toLocalDate(), d -> new double[2]);
            a[0]++;
            a[1] += b.total;
        }
        List<DayRow> out = new ArrayList<>();
        for (Map.Entry<LocalDate, double[]> e : m.entrySet()) {
            if (out.size() >= maxDays) break;
            out.add(new DayRow(e.getKey(), (int) e.getValue()[0], round2(e.getValue()[1])));
        }
        return out;
    }

    public List<SellerRow> topSellers(int limit) {
        Map<String, double[]> m = new LinkedHashMap<>();
        for (Bill b : bills)
            for (Line l : b.order.lines) {
                double[] a = m.computeIfAbsent(l.name, k -> new double[2]);
                a[0] += l.qty;
                a[1] += l.amount();
            }
        List<SellerRow> out = new ArrayList<>();
        for (Map.Entry<String, double[]> e : m.entrySet())
            out.add(new SellerRow(e.getKey(), (int) e.getValue()[0], round2(e.getValue()[1])));
        out.sort(Comparator.comparingInt(SellerRow::sold).reversed().thenComparing(Comparator.comparingDouble(SellerRow::revenue).reversed()));
        return out.size() > limit ? new ArrayList<>(out.subList(0, limit)) : out;
    }

    public List<MethodRow> byMethod() {
        Map<String, double[]> m = new LinkedHashMap<>();
        for (Bill b : bills) {
            double[] a = m.computeIfAbsent(b.method, k -> new double[2]);
            a[0]++;
            a[1] += b.total;
        }
        List<MethodRow> out = new ArrayList<>();
        for (Map.Entry<String, double[]> e : m.entrySet())
            out.add(new MethodRow(e.getKey(), (int) e.getValue()[0], round2(e.getValue()[1])));
        return out;
    }
}
