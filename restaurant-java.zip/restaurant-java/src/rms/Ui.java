package rms;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.JTextComponent;
import java.awt.*;
import java.util.Locale;

/** Small helpers shared by all screens. */
final class Ui {
    static final String RUPEE = "₹";
    static final Color BRAND = new Color(0xB5451B);
    static final Color BUSY = new Color(0xFDEEE6);
    static final Color OK = new Color(0x2E7D32);
    static final Color BAD = new Color(0xC62828);
    static final Color MUTED = new Color(0x7A6C5D);

    private Ui() {}

    static String money(double v) { return String.format(Locale.ENGLISH, "%s%,.2f", RUPEE, v); }

    static String plain(double v) { return String.format(Locale.ENGLISH, "%,.2f", v); }

    static DefaultTableModel model(String... cols) {
        return new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
    }

    static JButton button(String text, Runnable action) {
        JButton b = new JButton(text);
        b.addActionListener(e -> action.run());
        return b;
    }

    static JLabel heading(String text) {
        JLabel l = new JLabel(text);
        l.setFont(l.getFont().deriveFont(Font.BOLD, 16f));
        return l;
    }

    static void error(Component parent, Exception e) {
        JOptionPane.showMessageDialog(parent, e.getMessage(), "Cannot do that", JOptionPane.WARNING_MESSAGE);
    }

    static void info(Component parent, String msg) {
        JOptionPane.showMessageDialog(parent, msg, "Spice Route", JOptionPane.INFORMATION_MESSAGE);
    }

    /** Parses a number typed by the user. */
    static double number(String s) {
        try {
            return Double.parseDouble(s.trim().replace(",", ""));
        } catch (NumberFormatException | NullPointerException e) {
            throw new IllegalArgumentException("Please enter a valid number.");
        }
    }

    /** Like number() but an empty box counts as 0. */
    static double numberOrZero(String s) {
        return (s == null || s.isBlank()) ? 0 : number(s);
    }

    static String html(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    static void onChange(JTextComponent c, Runnable r) {
        c.getDocument().addDocumentListener(new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e) { r.run(); }
            @Override public void removeUpdate(DocumentEvent e) { r.run(); }
            @Override public void changedUpdate(DocumentEvent e) { r.run(); }
        });
    }
}
