package rms;

import rms.Model.Dish;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/** Manager screen: add dishes, change prices, switch dishes off when sold out. */
final class MenuPanel extends JPanel implements Refreshable {
    private final Store store;
    private final DefaultTableModel model = Ui.model("Dish", "Category", "Type", "Price", "Available");
    private final JTable table = new JTable(model);
    private final List<Dish> shown = new ArrayList<>();

    private final JTextField name = new JTextField(14);
    private final JComboBox<String> category = new JComboBox<>();
    private final JTextField price = new JTextField(6);
    private final JCheckBox veg = new JCheckBox("Veg", true);

    MenuPanel(Store store) {
        super(new BorderLayout(0, 10));
        this.store = store;
        setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        JPanel form = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        form.setBorder(BorderFactory.createTitledBorder("Add a dish"));
        form.add(new JLabel("Name"));
        form.add(name);
        form.add(category);
        form.add(new JLabel("Price"));
        form.add(price);
        form.add(veg);
        form.add(Ui.button("Add dish", this::addDish));
        add(form, BorderLayout.NORTH);

        table.setRowHeight(26);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        actions.add(Ui.button("Change price of selected", this::changePrice));
        actions.add(Ui.button("Switch selected on / off", this::toggle));
        JLabel hint = new JLabel("Dishes that are off cannot be ordered. New dishes do not use up stock until a recipe is added in Seed.java.");
        hint.setForeground(Ui.MUTED);
        actions.add(hint);
        add(actions, BorderLayout.SOUTH);
        refresh();
    }

    private Dish selected() {
        int r = table.getSelectedRow();
        if (r < 0 || r >= shown.size()) {
            Ui.info(this, "Select a dish in the table first.");
            return null;
        }
        return shown.get(r);
    }

    private void addDish() {
        try {
            store.addDish((String) category.getSelectedItem(), name.getText(), Ui.number(price.getText()), veg.isSelected());
            name.setText("");
            price.setText("");
            refresh();
        } catch (RuntimeException e) {
            Ui.error(this, e);
        }
    }

    private void changePrice() {
        Dish d = selected();
        if (d == null) return;
        String in = JOptionPane.showInputDialog(this, "New price for " + d.name, d.price);
        if (in == null) return;
        int row = table.getSelectedRow();
        try {
            store.setPrice(d.id, Ui.number(in));
            refresh();
            table.setRowSelectionInterval(row, row);
        } catch (RuntimeException e) {
            Ui.error(this, e);
        }
    }

    private void toggle() {
        Dish d = selected();
        if (d == null) return;
        int row = table.getSelectedRow();
        store.toggleAvailable(d.id);
        refresh();
        table.setRowSelectionInterval(row, row);
    }

    @Override public void refresh() {
        Object keep = category.getSelectedItem();
        category.removeAllItems();
        for (String c : store.categories) category.addItem(c);
        if (keep != null) category.setSelectedItem(keep);

        model.setRowCount(0);
        shown.clear();
        for (Dish d : store.menu) {
            shown.add(d);
            model.addRow(new Object[] {d.name, d.category, d.veg ? "Veg" : "Non-veg", Ui.money(d.price), d.available ? "Yes" : "OFF"});
        }
    }
}
