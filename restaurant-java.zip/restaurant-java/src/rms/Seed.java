package rms;

import rms.Model.DiningTable;
import rms.Model.Dish;
import rms.Model.Ingredient;

/** Sample restaurant data so the app is usable on the very first run. */
final class Seed {
    private Seed() {}

    static void fill(Store s) {
        for (String c : new String[] {"Starters", "Mains", "Breads", "Desserts", "Beverages"}) s.categories.add(c);

        ingredient(s, "Paneer", "kg", 8, 2);
        ingredient(s, "Chicken", "kg", 12, 3);
        ingredient(s, "Rice", "kg", 25, 5);
        ingredient(s, "Flour (maida)", "kg", 20, 5);
        ingredient(s, "Atta", "kg", 15, 4);
        ingredient(s, "Butter", "kg", 4, 1);
        ingredient(s, "Toor Dal", "kg", 10, 2);
        ingredient(s, "Milk", "l", 15, 4);
        ingredient(s, "Tea Leaves", "kg", 2, 0.5);
        ingredient(s, "Lime", "pcs", 60, 15);
        ingredient(s, "Mixed Veg", "kg", 10, 3);

        // dish(category, name, price, veg, then pairs of: ingredient, quantity per portion)
        dish(s, "Starters", "Paneer Tikka", 260, true, "Paneer", 0.15);
        dish(s, "Starters", "Chicken 65", 290, false, "Chicken", 0.20);
        dish(s, "Starters", "Veg Spring Rolls", 180, true, "Flour (maida)", 0.05, "Mixed Veg", 0.08);
        dish(s, "Mains", "Butter Chicken", 360, false, "Chicken", 0.25, "Butter", 0.03);
        dish(s, "Mains", "Paneer Butter Masala", 320, true, "Paneer", 0.18, "Butter", 0.03);
        dish(s, "Mains", "Dal Tadka", 220, true, "Toor Dal", 0.10);
        dish(s, "Mains", "Veg Biryani", 260, true, "Rice", 0.15, "Mixed Veg", 0.10);
        dish(s, "Breads", "Butter Naan", 55, true, "Flour (maida)", 0.08, "Butter", 0.01);
        dish(s, "Breads", "Tandoori Roti", 30, true, "Atta", 0.07);
        dish(s, "Desserts", "Gulab Jamun", 110, true);
        dish(s, "Desserts", "Ice Cream Scoop", 90, true);
        dish(s, "Beverages", "Masala Chai", 40, true, "Milk", 0.12, "Tea Leaves", 0.005);
        dish(s, "Beverages", "Fresh Lime Soda", 70, true, "Lime", 1.0);
        dish(s, "Beverages", "Cold Coffee", 120, true, "Milk", 0.25);

        String[] labels = {"T1", "T2", "T3", "T4", "T5", "T6", "T7", "T8"};
        int[] seats = {2, 2, 4, 4, 4, 6, 6, 8};
        for (int i = 0; i < labels.length; i++) {
            DiningTable t = new DiningTable();
            t.id = i + 1;
            t.label = labels[i];
            t.seats = seats[i];
            s.tables.add(t);
        }
    }

    private static void ingredient(Store s, String name, String unit, double stock, double reorder) {
        Ingredient i = new Ingredient();
        i.name = name;
        i.unit = unit;
        i.stock = stock;
        i.reorderLevel = reorder;
        s.ingredients.add(i);
    }

    private static void dish(Store s, String category, String name, double price, boolean veg, Object... recipe) {
        Dish d = s.addDish(category, name, price, veg);
        for (int i = 0; i + 1 < recipe.length; i += 2) {
            d.recipe.put((String) recipe[i], ((Number) recipe[i + 1]).doubleValue());
        }
    }
}
