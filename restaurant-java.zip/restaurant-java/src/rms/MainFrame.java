package rms;

import javax.swing.*;
import java.awt.*;

/** The main window with one tab per screen. */
final class MainFrame extends JFrame {
    MainFrame(Store store) {
        super("Spice Route - Restaurant Manager");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1100, 720);
        setMinimumSize(new Dimension(900, 600));
        setLocationRelativeTo(null);

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Floor", new FloorPanel(store));
        tabs.addTab("Kitchen", new KitchenPanel(store));
        tabs.addTab("Menu", new MenuPanel(store));
        tabs.addTab("Inventory", new InventoryPanel(store));
        tabs.addTab("Reports", new ReportsPanel(store));
        tabs.addChangeListener(e -> ((Refreshable) tabs.getSelectedComponent()).refresh());
        add(tabs);

        // The floor and kitchen boards refresh themselves every 5 seconds.
        new javax.swing.Timer(5000, e -> {
            Component c = tabs.getSelectedComponent();
            if (c instanceof FloorPanel || c instanceof KitchenPanel) ((Refreshable) c).refresh();
        }).start();
    }
}
