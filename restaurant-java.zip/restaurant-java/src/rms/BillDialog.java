package rms;

import rms.Model.*;

import javax.swing.*;
import java.awt.*;
import java.awt.print.PrinterException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/** Bill preview with discount + payment method. After "Collect payment" it becomes a printable receipt. */
final class BillDialog extends JDialog {
    private static final int W = 38;
    private static final DateTimeFormatter WHEN = DateTimeFormatter.ofPattern("dd MMM yyyy, HH:mm");

    private final Store store;
    private final Order order;
    private final JTextArea receipt = new JTextArea(20, 42);
    private final JTextField discount = new JTextField("0", 5);
    private final JComboBox<String> method = new JComboBox<>(new String[] {"Cash", "Card", "UPI"});
    private final JButton collect;
    private Bill bill;

    BillDialog(Window owner, Store store, Order order) {
        super(owner, "Bill - Table " + store.tableLabel(order.tableId), ModalityType.APPLICATION_MODAL);
        this.store = store;
        this.order = order;

        receipt.setEditable(false);
        receipt.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));
        receipt.setMargin(new Insets(10, 12, 10, 12));

        collect = Ui.button("Collect payment", this::collectPayment);
        Ui.onChange(discount, this::preview);

        JPanel controls = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 8));
        controls.add(new JLabel("Discount %"));
        controls.add(discount);
        controls.add(new JLabel("Paid by"));
        controls.add(method);
        controls.add(collect);
        controls.add(Ui.button("Print", this::printReceipt));
        controls.add(Ui.button("Close", this::dispose));

        setLayout(new BorderLayout());
        add(new JScrollPane(receipt), BorderLayout.CENTER);
        add(controls, BorderLayout.SOUTH);
        preview();
        pack();
        setLocationRelativeTo(owner);
    }

    boolean paid() { return bill != null; }

    private double discountPct() {
        try {
            return Math.min(100, Math.max(0, Ui.numberOrZero(discount.getText())));
        } catch (IllegalArgumentException e) {
            return 0;
        }
    }

    private void preview() {
        if (bill != null) return;
        double sub = Store.round2(order.subtotal());
        double[] c = Store.calc(sub, discountPct());
        receipt.setText(render(store.tableLabel(order.tableId), order, sub, c[0], c[1], c[2], LocalDateTime.now(), null));
        receipt.setCaretPosition(0);
    }

    private void collectPayment() {
        try {
            bill = store.bill(order.id, discountPct(), (String) method.getSelectedItem());
        } catch (RuntimeException e) {
            Ui.error(this, e);
            return;
        }
        discount.setEnabled(false);
        method.setEnabled(false);
        collect.setEnabled(false);
        receipt.setText(render(bill.tableLabel, order, bill.subtotal, bill.discount, bill.tax, bill.total,
                bill.paidAt, "PAID by " + bill.method.toUpperCase(Locale.ROOT)));
        receipt.setCaretPosition(0);
    }

    private void printReceipt() {
        try {
            receipt.print();
        } catch (PrinterException e) {
            Ui.info(this, "Could not print: " + e.getMessage());
        }
    }

    // ------------------------------------------------------------------ receipt text

    static String render(String tableLabel, Order o, double sub, double disc, double tax, double total,
                         LocalDateTime when, String paidLine) {
        String rule = "-".repeat(W);
        StringBuilder sb = new StringBuilder();
        sb.append(center("SPICE ROUTE")).append('\n');
        sb.append(center("Table " + tableLabel + "   Order #" + o.id)).append('\n');
        sb.append(center(when.format(WHEN))).append('\n');
        sb.append(rule).append('\n');
        sb.append(String.format(Locale.ENGLISH, "%-20s %3s %12s%n", "Item", "Qty", "Amount (INR)"));
        sb.append(rule).append('\n');
        for (Line l : o.lines) {
            sb.append(String.format(Locale.ENGLISH, "%-20s %3d %12s%n", cut(l.name, 20), l.qty, Ui.plain(l.amount())));
        }
        sb.append(rule).append('\n');
        sb.append(row("Subtotal", Ui.plain(sub)));
        if (disc > 0) sb.append(row("Discount", "-" + Ui.plain(disc)));
        sb.append(row("GST (" + (int) Math.round(Store.GST_RATE * 100) + "%)", Ui.plain(tax)));
        sb.append(rule).append('\n');
        sb.append(row("TOTAL", Ui.plain(total)));
        sb.append(rule).append('\n');
        if (paidLine != null) {
            sb.append(center(paidLine)).append('\n');
            sb.append(center("Thank you! Visit again.")).append('\n');
        } else {
            sb.append(center("(not paid yet)")).append('\n');
        }
        return sb.toString();
    }

    private static String row(String label, String value) {
        return String.format(Locale.ENGLISH, "%-24s %12s%n", label, value);
    }

    private static String cut(String s, int n) { return s.length() <= n ? s : s.substring(0, n - 1) + "."; }

    private static String center(String s) {
        int pad = Math.max(0, (W - s.length()) / 2);
        return " ".repeat(pad) + s;
    }
}
