package rms;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import java.nio.file.Path;

/** Start here: java -cp out rms.Main */
public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) {
                // fall back to the default look
            }
            Store store = Store.load(Path.of("restaurant-data.ser"));
            new MainFrame(store).setVisible(true);
        });
    }
}
