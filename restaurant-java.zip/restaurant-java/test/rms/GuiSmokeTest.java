package rms;

import rms.Model.*;

import javax.swing.JTable;
import java.awt.Component;
import java.awt.Container;

/** Builds every screen without opening a window and checks they fill in correctly. */
public class GuiSmokeTest {
    private static int checks = 0;

    private static void check(boolean ok, String what) {
        checks++;
        if (!ok) throw new AssertionError("FAILED: " + what);
    }

    private static int rows(Container c) {
        int n = 0;
        for (Component k : c.getComponents()) {
            if (k instanceof JTable t) n += t.getRowCount();
            else if (k instanceof Container cc) n += rows(cc);
        }
        return n;
    }

    public static void main(String[] args) {
        System.setProperty("java.awt.headless", "true");
        Store s = Store.inMemory();

        FloorPanel floor = new FloorPanel(s);
        KitchenPanel kitchen = new KitchenPanel(s);
        MenuPanel menu = new MenuPanel(s);
        InventoryPanel inv = new InventoryPanel(s);
        ReportsPanel reports = new ReportsPanel(s);
        check(rows(menu) == 14, "menu screen lists 14 dishes");
        check(rows(inv) == 11, "inventory screen lists 11 ingredients");
        check(rows(reports) == 0, "reports empty at start");

        Dish naan = s.menu.stream().filter(d -> d.name.equals("Butter Naan")).findFirst().orElseThrow();
        Line l = s.addItem(1, naan.id, 2, "<b>crispy</b> & hot"); // odd characters must not break the HTML renderers
        s.advance(l.id);
        floor.refresh();
        kitchen.refresh();
        check(s.kitchenTickets(Status.PREPARING).size() == 1, "kitchen has 1 preparing ticket");
        s.advance(l.id);
        s.serve(l.id);
        Order o = s.openOrder(1);
        Bill b = s.bill(o.id, 5, "Card");

        for (Refreshable r : new Refreshable[] {floor, kitchen, menu, inv, reports}) r.refresh();
        check(rows(reports) == 3, "reports: 1 day + 1 seller + 1 method");

        String text = BillDialog.render("T1", o, b.subtotal, b.discount, b.tax, b.total, b.paidAt, "PAID by CARD");
        check(text.contains("Butter Naan") && text.contains("TOTAL") && text.contains("PAID by CARD"), "receipt text complete");
        System.out.println(text);
        System.out.println("GUI smoke test passed (" + checks + " checks).");
    }
}
