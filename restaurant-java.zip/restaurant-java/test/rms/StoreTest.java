package rms;

import rms.Model.*;

import java.nio.file.Files;
import java.nio.file.Path;

/** Plain-Java tests (no JUnit needed). Run with run-tests.bat / run-tests.sh. */
public class StoreTest {
    private static int checks = 0;

    private static void check(boolean ok, String what) {
        checks++;
        if (!ok) throw new AssertionError("FAILED: " + what);
    }

    private static boolean near(double a, double b) { return Math.abs(a - b) < 0.005; }

    private static Dish dish(Store s, String name) {
        for (Dish d : s.menu) if (d.name.equals(name)) return d;
        throw new IllegalStateException("no dish " + name);
    }

    private static void expectFail(Runnable r, String what) {
        try { r.run(); } catch (RuntimeException e) { checks++; return; }
        throw new AssertionError("Expected an error: " + what);
    }

    public static void main(String[] args) throws Exception {
        seedData();
        fullFlow();
        removeFreesTable();
        unavailableItem();
        menuAndInventoryAdmin();
        persistence();
        System.out.println("All tests passed (" + checks + " checks).");
    }

    static void seedData() {
        Store s = Store.inMemory();
        check(s.menu.size() == 14, "14 sample dishes");
        check(s.tables.size() == 8, "8 tables");
        check(s.openOrderCount() == 0, "no open orders at start");
        check(s.lowStockCount() == 0, "nothing low at start");
    }

    static void fullFlow() {
        Store s = Store.inMemory();
        Dish paneer = dish(s, "Paneer Butter Masala");
        Dish naan = dish(s, "Butter Naan");

        Line a = s.addItem(3, paneer.id, 2, "");
        Line b = s.addItem(3, naan.id, 4, "extra butter");
        Order o = s.openOrder(3);
        check(o != null && o.lines.size() == 2, "order created with 2 lines");
        check(s.openOrderCount() == 1, "one open order");

        check(s.kitchenTickets(Status.NEW).size() == 2, "2 new tickets");
        s.advance(a.id);
        s.advance(a.id);
        s.advance(b.id);
        check(s.kitchenTickets(Status.READY).size() == 1, "1 ready ticket");
        check(s.kitchenTickets(Status.PREPARING).size() == 1, "1 preparing ticket");
        s.advance(b.id);

        expectFail(() -> s.removeLine(a.id), "cannot remove an item the kitchen started");
        s.serve(a.id);
        s.serve(b.id);
        expectFail(() -> s.serve(a.id), "cannot serve twice");

        double paneerBefore = s.findIngredient("Paneer").stock;
        Bill bill = s.bill(o.id, 10, "UPI");
        check(near(bill.subtotal, 860), "subtotal 860");
        check(near(bill.discount, 86), "discount 86");
        check(near(bill.tax, 38.70), "GST 38.70");
        check(near(bill.total, 812.70), "total 812.70");
        check(s.openOrder(3) == null, "table free after billing");
        check(near(paneerBefore - s.findIngredient("Paneer").stock, 0.36), "paneer stock cut by 0.36 kg");

        expectFail(() -> s.bill(o.id, 0, "Cash"), "cannot bill the same order twice");
        check(s.bills.size() == 1, "only one bill exists");

        check(near(s.todaySales(), 812.70), "today's sales");
        check(s.todayBills() == 1, "today's bill count");
        check(s.dailyRevenue(14).size() == 1, "one day in report");
        check(s.topSellers(10).get(0).name().equals("Butter Naan"), "naan is best seller (4 sold)");
        check(s.byMethod().get(0).method().equals("UPI"), "payment method split");
    }

    static void removeFreesTable() {
        Store s = Store.inMemory();
        Line l = s.addItem(1, dish(s, "Dal Tadka").id, 1, "");
        check(s.openOrder(1) != null, "table 1 busy");
        s.removeLine(l.id);
        check(s.openOrder(1) == null, "table 1 free after removing last item");
        expectFail(() -> s.bill(999, 0, "Cash"), "unknown order cannot be billed");
    }

    static void unavailableItem() {
        Store s = Store.inMemory();
        Dish tikka = dish(s, "Paneer Tikka");
        s.toggleAvailable(tikka.id);
        expectFail(() -> s.addItem(1, tikka.id, 1, ""), "switched-off dish cannot be ordered");
        s.toggleAvailable(tikka.id);
        s.addItem(1, tikka.id, 1, "");
        check(s.openOrder(1) != null, "dish orderable again");
    }

    static void menuAndInventoryAdmin() {
        Store s = Store.inMemory();
        Dish d = s.addDish("Desserts", "Rasmalai", 140, true);
        check(near(s.findDish(d.id).price, 140), "new dish added");
        s.setPrice(d.id, 150);
        check(near(s.findDish(d.id).price, 150), "price changed");
        expectFail(() -> s.addDish("Desserts", " ", 10, true), "blank name rejected");

        double before = s.findIngredient("Paneer").stock;
        s.restock("Paneer", 5);
        check(near(s.findIngredient("Paneer").stock, before + 5), "restocked");
        s.addIngredient("Saffron", "g", 1, 5);
        check(s.lowStockCount() == 1, "new low-stock ingredient counted");
        expectFail(() -> s.addIngredient("paneer", "kg", 1, 1), "duplicate ingredient rejected");
        expectFail(() -> s.restock("Paneer", 0), "zero restock rejected");

        double[] c = Store.calc(1000, 150); // discount is capped at 100%
        check(near(c[0], 1000) && near(c[2], 0), "discount capped at 100%");
    }

    static void persistence() throws Exception {
        Path f = Files.createTempFile("rms-test", ".ser");
        Files.delete(f); // load() should create it
        Store s = Store.load(f);
        check(Files.exists(f), "data file created on first load");
        s.addItem(2, dish(s, "Veg Biryani").id, 3, "no onion");
        Bill b = s.bill(s.openOrder(2).id, 0, "Cash");

        Store again = Store.load(f);
        check(again.bills.size() == 1, "bill survives restart");
        check(near(again.bills.get(0).total, b.total), "bill total survives restart");
        check(again.bills.get(0).order.lines.get(0).note.equals("no onion"), "order note survives restart");
        check(again.todayBills() == 1, "report works after restart");
        Files.deleteIfExists(f);
    }
}
