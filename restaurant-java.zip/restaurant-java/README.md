# Restaurant Manager (Java Swing)

Ek complete restaurant management desktop app, pure Java mein. **Koi extra library, database ya internet nahi chahiye** - sirf JDK.

## Kya karta hai (start se end tak)

| Step | Screen | Kaam |
|---|---|---|
| Seating | **Floor** | Table map (free / occupied), aaj ki sales, open orders, low-stock alert |
| Order | Table pe click | Dish + quantity + note add karo; kitchen start kare tab tak item hata sakte ho |
| Cooking | **Kitchen** | Tickets: New -> Preparing -> Ready (har 5 sec auto-refresh) |
| Serve | Table screen | Ready items ko "served" mark karo |
| Billing | Generate bill | Discount %, 5% GST, Cash/Card/UPI, printable receipt, table free |
| Stock | **Inventory** | Bill pe recipe ke hisaab se ingredient automatic kam, low-stock flag, restock |
| Menu | **Menu** | Nayi dish, price change, sold-out dish ko OFF karo |
| Reports | **Reports** | Daily revenue, best sellers, payment method split |

Data apne aap `restaurant-data.ser` file me save hota hai - app band karke dobara kholo, sab wahi milega.
Reset karna ho to wo file delete kar do.

## Chalane ka tarika

1. **JDK 17 ya naya** install karo (recommended: Temurin 21 from https://adoptium.net). Installer me "Add to PATH" ON rakho.
2. Zip ko **Extract All** karo.
3. **Windows:** `run.bat` pe double-click karo.
   **Mac / Linux:** terminal me `sh run.sh`

Tests chalane ke liye: `run-tests.bat` (Windows) ya `sh run.sh test` (Mac/Linux).

Haath se chalana ho to:
```
javac -encoding UTF-8 -d out src/rms/*.java
java -cp out rms.Main
```

## Project layout

```
src/rms/Model.java      data classes (Dish, Order, Line, Bill, Ingredient...)
src/rms/Store.java      saari business logic + file save/load (screens se alag, testable)
src/rms/Seed.java       sample menu, recipes, ingredients, 8 tables
src/rms/*Panel.java     Floor, Kitchen, Menu, Inventory, Reports screens
src/rms/OrderDialog.java, BillDialog.java
src/rms/MainFrame.java, Main.java
test/rms/               StoreTest (42 checks), GuiSmokeTest
```

## Badalna ho to

- **GST rate:** `Store.java` me `GST_RATE`
- **Restaurant ka naam:** `MainFrame.java` (window title) aur `BillDialog.java` (receipt)
- **Sample menu / tables:** `Seed.java` (data file delete karke dobara chalao)

## Aage ke ideas

- Login with roles (waiter / chef / manager)
- Table reservation, split bill, tips
- Database (SQLite/PostgreSQL) ya Spring Boot web version
