@echo off
rem Compiles everything and runs the self-checks (no window opens).
cd /d "%~dp0"

where javac >nul 2>nul
if errorlevel 1 (
  echo Java JDK nahi mila. Pehle https://adoptium.net se install karo.
  pause
  exit /b 1
)

if not exist out mkdir out
javac -encoding UTF-8 -d out src\rms\*.java test\rms\*.java
if errorlevel 1 ( pause & exit /b 1 )

java -Djava.awt.headless=true -cp out rms.StoreTest
java -Djava.awt.headless=true -cp out rms.GuiSmokeTest
pause
